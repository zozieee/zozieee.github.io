<html>
  <head>
    <title>Response saved</title>
  </head>
  <body>

     <p>Your response,  username:  <?php echo $_POST["un"]; ?> 
	 and password: <?php echo $_POST["pw"]; ?> have been added to the list!
     </p>
    
   
  </body>
</html>