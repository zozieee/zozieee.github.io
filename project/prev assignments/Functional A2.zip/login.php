<html>
  <head>
    <title>Form page</title>
  </head>
  <body>
		
		  <p>Login</p>
		  <p> Programmer: Zoe Cope </p>
		  <p> Enter your username and password: </p>
		

		<form action="response.php" method="post"> 
		  Username: <input type="text" name="un"><br>
		  Password: <input type="text" name="pw"><br>
		  <button type="submit" name="button">Submit</button>
		</form>
	</body>
</html>